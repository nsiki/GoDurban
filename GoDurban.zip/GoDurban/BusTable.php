<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h1>Bus Route</h1>
<table>
<caption>BusRoutin</caption>

     <tr>
	     <td>BusDriver</td>
		 <td>BusNumber</td>
	 </tr>
</table>
</body>
</html>