<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
 <h3><image src="GoDurban.png" style="width:700px;height:400px;"></h3>
  <h1>Sign Up to Ride</h1>
  <h2>Always there on time</h2>
   <form>
      <input type="text" placeholder="First Name"><br>
	  <input type="text" placeholder="Last Name"><br>
	  <input type="number" placeholder="cellphone number"><br>
	  <input type="email" placeholder="Email"><br>
	  <input type="password" placeholder="Password"><br>
	  <input type="password" placeholder="Confirm Password"><br>
	  
	  <input type="submit" name="Sign Up ">
   </form>

</body>
<html>